import 'package:flutter/material.dart';
class ThemeProvider extends ChangeNotifier{
  ThemeMode _themeMode = ThemeMode.system;
  ThemeMode get themeMode => _themeMode;
  bool get isDarkMode =>_themeMode == ThemeMode.dark;
  void setThemeMode(ThemeMode mode){
    if(_themeMode == mode) return;
    _themeMode = mode;
    notifyListeners();
  }
  void toggleTheme(){
    _themeMode = isDarkMode ? ThemeMode.light : ThemeMode.dark;
    notifyListeners();
  }
}