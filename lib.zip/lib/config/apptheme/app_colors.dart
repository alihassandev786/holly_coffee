
import 'package:flutter/material.dart';

class AppColors {
 

  static const Color primary = Color(0xFFCE8A1E);
  static const Color secondary = Color(0xFFF3F3F3);

  static const Color surface = Color(0xFFFFFFFF);
  static const Color surfaceVariant = Color(0xFFF3F3F3);
  static const Color bgcolor = Colors.white;

  static const Color textcolor1 = Color(0xFF000000);
  static const Color textcolor2 = Color(0xFF717171);

  static const Color border = Color(0xFFD0CEC9);
  static const Color error = Colors.red;
  static const Color success = Color(0xff148949);
  static const Color circlecolor = Color(0xff644832);
  static const Color clipoval = Color(0xffFFFFFF);
}
